package com.cognizant.notificationservice.dao;
import com.cognizant.notificationservice.entity.Notification; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserId(Long userId);
    List<Notification> findByUserIdAndStatus(Long userId, Notification.NotificationStatus status);
}
