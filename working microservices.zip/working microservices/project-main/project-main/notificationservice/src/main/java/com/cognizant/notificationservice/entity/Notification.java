package com.cognizant.notificationservice.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.*; import java.time.*;
@Entity @Table(name="notifications") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) private Long notificationId;
    private Long userId;
    private Long entityId;

    @Column(columnDefinition="TEXT", nullable=false)
    private String message;
    @Enumerated(EnumType.STRING)
    private NotificationCategory category;
    @Enumerated(EnumType.STRING) @Builder.Default
    private NotificationStatus status = NotificationStatus.UNREAD;
    @Builder.Default
    private LocalDateTime createdDate = LocalDateTime.now();
    @CreationTimestamp
    private LocalDateTime createdAt;

    //enums
    public enum NotificationCategory { APPLICATION, DISBURSEMENT, PAYMENT, COMPLIANCE, PROGRAM, GENERAL }  // ✅ ADDED PAYMENT
    public enum NotificationStatus { UNREAD, READ }
}
