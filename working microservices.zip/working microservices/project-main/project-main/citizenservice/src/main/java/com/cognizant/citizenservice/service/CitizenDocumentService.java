package com.cognizant.citizenservice.service;

import com.cognizant.citizenservice.dto.*;
import java.util.List;

public interface CitizenDocumentService {
    DocumentResponseDto uploadDocument(DocumentRequestDto dto);
    DocumentResponseDto getDocumentById(Long id);
    List<DocumentResponseDto> getDocumentsByCitizen(Long citizenId);
    DocumentResponseDto verifyDocument(Long id, String status);
}
