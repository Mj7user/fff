package com.cognizant.citizenservice.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "citizen_documents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @Column(nullable = false)
    private Long citizenId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DocType docType;

    @Column(nullable = false)
    private String fileUri;

    @Builder.Default
    private LocalDate uploadedDate = LocalDate.now();

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private VerificationStatus verificationStatus = VerificationStatus.PENDING;

    @CreationTimestamp
    private LocalDateTime createdAt;

    public enum DocType { ID_PROOF, RESIDENCE, INCOME, OTHER }
    public enum VerificationStatus { PENDING, VERIFIED, REJECTED }
}
