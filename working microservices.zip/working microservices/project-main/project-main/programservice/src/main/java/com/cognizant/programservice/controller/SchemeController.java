package com.cognizant.programservice.controller;

import com.cognizant.programservice.dto.SchemeRequestDto;

import com.cognizant.programservice.dto.SchemeResponseDto;

import com.cognizant.programservice.entity.Scheme;
import com.cognizant.programservice.service.SchemeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/schemes")
@RequiredArgsConstructor
public class SchemeController {

    private final SchemeService schemeService;

    @PostMapping
    public ResponseEntity<SchemeResponseDto> createScheme(
            @Valid @RequestBody SchemeRequestDto request
    ) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(schemeService.createScheme(request));
    }

    @GetMapping("/{id}")
    public ResponseEntity<SchemeResponseDto> getSchemeById(
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(
                schemeService.getSchemeById(id)
        );
    }

    @GetMapping
    public ResponseEntity<Page<SchemeResponseDto>> getAllSchemes(
            @PageableDefault(size = 20) Pageable pageable
    ) {
        return ResponseEntity.ok(
                schemeService.getAllSchemes(pageable)
        );
    }

    @GetMapping("/program/{programId}")
    public ResponseEntity<List<SchemeResponseDto>> getSchemesByProgram(
            @PathVariable Long programId
    ) {
        return ResponseEntity.ok(
                schemeService.getSchemesByProgram(programId)
        );
    }

    @PutMapping("/{id}")
    public ResponseEntity<SchemeResponseDto> updateScheme(
            @PathVariable Long id,
            @Valid @RequestBody SchemeRequestDto request
    ) {
        return ResponseEntity.ok(
                schemeService.updateScheme(id, request)
        );
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<String> updateSchemeStatus(
            @PathVariable Long id,
            @RequestParam Scheme.SchemeStatus status
    ) {
        schemeService.updateSchemeStatus(id, status);
        return ResponseEntity.ok("Scheme status updated");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteScheme(
            @PathVariable Long id
    ) {
        schemeService.deleteScheme(id);
        return ResponseEntity.ok("Scheme deleted");
    }
}
