package com.cognizant.programservice;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
@SpringBootApplication @EnableFeignClients
public class ProgramserviceApplication {
    public static void main(String[] args) { SpringApplication.run(ProgramserviceApplication.class, args); }
}
