package com.cognizant.programservice.service;

import com.cognizant.programservice.dto.ProgramRequestDto;
import com.cognizant.programservice.dto.ProgramResponseDto;
import com.cognizant.programservice.entity.Program;
import com.cognizant.programservice.exception.DuplicateResourceException;
import com.cognizant.programservice.exception.ResourceNotFoundException;
import com.cognizant.programservice.dao.ProgramRepository;
import com.cognizant.programservice.service.ProgramService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProgramServiceImpl implements ProgramService {

    private final ProgramRepository programRepository;

    @Override
    @Transactional
    public ProgramResponseDto createProgram(ProgramRequestDto request) {

        if (programRepository.existsByTitle(request.getTitle())) {
            throw new DuplicateResourceException(
                    String.format("Program already exists with title: '%s'", request.getTitle())
            );


        }
        Program program = Program.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .budget(request.getBudget())
                .status(request.getStatus() != null ? request.getStatus() : Program.ProgramStatus.DRAFT)
                .build();
        return mapToResponse(programRepository.save(program));
    }

    @Override
    public ProgramResponseDto getProgramById(Long id) {
        return mapToResponse(programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Program", id)));
    }

    @Override
    public Page<ProgramResponseDto> getAllPrograms(Pageable pageable) {
        return programRepository.findAll(pageable).map(this::mapToResponse);
    }

    @Override
    public Page<ProgramResponseDto> getProgramsByStatus(Program.ProgramStatus status, Pageable pageable) {
        return programRepository.findByStatus(status, pageable).map(this::mapToResponse);
    }

    @Override
    public Page<ProgramResponseDto> searchPrograms(String keyword, Pageable pageable) {
        return programRepository.searchByTitle(keyword, pageable).map(this::mapToResponse);
    }

    @Override
    @Transactional
    public ProgramResponseDto updateProgram(Long id, ProgramRequestDto request) {
        Program program = programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Program", id));

        if (!program.getTitle().equals(request.getTitle()) &&
                programRepository.existsByTitle(request.getTitle())) {
            throw new DuplicateResourceException(
                    String.format("Program already exists with title: '%s'", request.getTitle())
            );
        }
        program.setTitle(request.getTitle());
        program.setDescription(request.getDescription());
        program.setStartDate(request.getStartDate());
        program.setEndDate(request.getEndDate());
        program.setBudget(request.getBudget());
        if (request.getStatus() != null) program.setStatus(request.getStatus());
        return mapToResponse(programRepository.save(program));
    }

    @Override
    @Transactional
    public void updateProgramStatus(Long id, Program.ProgramStatus status) {
        Program program = programRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Program", id));
        program.setStatus(status);
        programRepository.save(program);
    }

    @Override
    @Transactional
    public void deleteProgram(Long id) {
        if (!programRepository.existsById(id)) throw new ResourceNotFoundException("Program", id);
        programRepository.deleteById(id);
    }

    private ProgramResponseDto mapToResponse(Program p) {
        return ProgramResponseDto.builder()
                .programId(p.getProgramId())
                .title(p.getTitle())
                .description(p.getDescription())
                .startDate(p.getStartDate())
                .endDate(p.getEndDate())
                .budget(p.getBudget())
                .status(p.getStatus())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
