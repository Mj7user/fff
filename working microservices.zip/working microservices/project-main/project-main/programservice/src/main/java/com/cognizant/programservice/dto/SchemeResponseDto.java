package com.cognizant.programservice.dto;

import com.cognizant.programservice.entity.Scheme;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class SchemeResponseDto {
    private Long schemeId;
    private Long programId;
    private String programTitle;
    private String title;
    private String description;
    private BigDecimal budget;
    private String eligibilityCriteria;
    private Scheme.SchemeStatus status;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
