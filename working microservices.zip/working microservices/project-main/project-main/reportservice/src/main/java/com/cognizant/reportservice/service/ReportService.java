package com.cognizant.reportservice.service;
import com.cognizant.reportservice.dto.*; import java.util.List;
public interface ReportService {
    ReportResponseDto generateReport(ReportRequestDto dto);
    ReportResponseDto getReportById(Long id);
    List<ReportResponseDto> getAllReports();
    List<ReportResponseDto> getReportsByScope(String scope);
}
