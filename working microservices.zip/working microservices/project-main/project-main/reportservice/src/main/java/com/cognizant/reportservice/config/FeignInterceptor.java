package com.cognizant.reportservice.config;
import feign.RequestInterceptor; import feign.RequestTemplate; import org.springframework.beans.factory.annotation.Value; import org.springframework.context.annotation.Configuration;
@Configuration public class FeignInterceptor implements RequestInterceptor {
    @Value("${val}") public String keyForInternalService;
    @Override public void apply(RequestTemplate t) { t.header("X-Internal-Service-Key", keyForInternalService); }
}
