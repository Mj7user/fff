package com.cognizant.reportservice.externalservice;
import org.springframework.cloud.openfeign.FeignClient; import org.springframework.web.bind.annotation.GetMapping;
@FeignClient(name = "disbursement-service")
public interface DisbursementServiceClient { @GetMapping("/disbursements") Object getAllDisbursements(); }
