package com.cognizant.userservice.config;

import com.cognizant.userservice.entity.User;
import com.cognizant.userservice.dao.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class OfficerInit implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception{

        createOfficer("welfare Officer","welfareofficer@gmail.com", "1234567890","welfareofficer", User.Role.WELFARE_OFFICER);
        createOfficer("compilance officer","complianceofficer@gmail.com", "0987654321","complianceofficer", User.Role.COMPLIANCE_OFFICER);
        createOfficer("administrator","administrator@gmail.com", "1212121212","administrator", User.Role.ADMINISTRATOR);
        createOfficer("governmentauditor","governmentauditor@gmail.com", "2323232323","governmentauditor",User.Role.GOVERNMENT_AUDITOR);
        createOfficer("programmanager","programmanager@gmail.com", "3435454565","programmanager",User.Role.PROGRAM_MANAGER);
    }

    private void createOfficer(String name,String email, String phone, String rawPassword, User.Role role) {
        if (userRepository.existsByEmail(email)) {
            return;
        }

        User officer = new User();
        officer.setName(name);
        officer.setEmail(email);
        officer.setPhone(phone);
        officer.setPassword(passwordEncoder.encode(rawPassword));
        officer.setRole(role);

        userRepository.save(officer);
        System.out.println("Created officer: " + email);
    }
}