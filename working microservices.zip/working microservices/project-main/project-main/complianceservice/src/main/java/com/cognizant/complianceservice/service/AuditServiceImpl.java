package com.cognizant.complianceservice.service;
import com.cognizant.complianceservice.dao.AuditRepository; import com.cognizant.complianceservice.dto.*; import com.cognizant.complianceservice.entity.Audit;
import com.cognizant.complianceservice.exception.ResourceNotFoundException; import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service; import java.util.List; import java.util.stream.Collectors;
@Service @RequiredArgsConstructor
public class AuditServiceImpl implements AuditService {
    private final AuditRepository auditRepository;
     @Override public AuditResponseDto createAudit(AuditRequestDto dto) {
         Audit a = Audit.builder().officerId(dto.getOfficerId()).scope(dto.getScope()).findings(dto.getFindings()).userId(dto.getUserId()).citizenId(dto.getCitizenId()).modeOfApplication(dto.getModeOfApplication()).build();
         return toDto(auditRepository.save(a));
     }
    @Override public AuditResponseDto getAuditById(Long id) { return toDto(auditRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Audit not found: " + id))); }
    @Override public List<AuditResponseDto> getAllAudits() { return auditRepository.findAll().stream().map(this::toDto).collect(Collectors.toList()); }
    @Override public AuditResponseDto updateStatus(Long id, String status) {
        Audit a = auditRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Audit not found: " + id));
        a.setStatus(Audit.AuditStatus.valueOf(status.toUpperCase()));
        return toDto(auditRepository.save(a));
    }
     private AuditResponseDto toDto(Audit a) { return AuditResponseDto.builder().auditId(a.getAuditId()).officerId(a.getOfficerId()).scope(a.getScope()).findings(a.getFindings()).userId(a.getUserId()).citizenId(a.getCitizenId()).modeOfApplication(a.getModeOfApplication()).date(a.getDate()).status(a.getStatus()).createdAt(a.getCreatedAt()).build(); }
}
