package com.cognizant.complianceservice.dto;
import com.cognizant.complianceservice.entity.ComplianceRecord; import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecordRequestDto {
    private Long entityId;
    private ComplianceRecord.EntityType type;
    private ComplianceRecord.ComplianceResult result;
    private String notes;
}
