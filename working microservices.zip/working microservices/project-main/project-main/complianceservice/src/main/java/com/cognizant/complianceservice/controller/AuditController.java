package com.cognizant.complianceservice.controller;
import com.cognizant.complianceservice.dto.*; import com.cognizant.complianceservice.service.AuditService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/audits") @RequiredArgsConstructor
public class AuditController {
    private final AuditService auditService;
    @PostMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<AuditResponseDto> create
            (@RequestBody AuditRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(auditService.createAudit(dto));
    }
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<AuditResponseDto> getById
            (@PathVariable Long id) {
        return ResponseEntity.ok(auditService.getAuditById(id));
    }
    @GetMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','ADMINISTRATOR')")
    public ResponseEntity<List<AuditResponseDto>> getAll() {
        return ResponseEntity.ok(auditService.getAllAudits());
    }
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('COMPLIANCE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<AuditResponseDto> updateStatus
            (@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(auditService.updateStatus(id, status));
    }
}
