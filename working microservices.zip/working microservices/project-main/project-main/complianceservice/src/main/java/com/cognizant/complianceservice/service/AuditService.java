package com.cognizant.complianceservice.service;
import com.cognizant.complianceservice.dto.*; import java.util.List;
public interface AuditService {
    AuditResponseDto createAudit(AuditRequestDto dto);
    AuditResponseDto getAuditById(Long id);
    List<AuditResponseDto> getAllAudits();
    AuditResponseDto updateStatus(Long id, String status);
}
