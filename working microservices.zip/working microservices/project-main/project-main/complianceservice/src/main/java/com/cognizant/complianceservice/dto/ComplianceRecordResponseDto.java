package com.cognizant.complianceservice.dto;
import com.cognizant.complianceservice.entity.ComplianceRecord; import lombok.*; import java.time.*;
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecordResponseDto { private Long complianceId; private Long entityId; private ComplianceRecord.EntityType type; private ComplianceRecord.ComplianceResult result; private LocalDate date; private String notes; private LocalDateTime createdAt; }
