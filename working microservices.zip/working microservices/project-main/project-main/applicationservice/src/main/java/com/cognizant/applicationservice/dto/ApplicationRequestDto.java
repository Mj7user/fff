package com.cognizant.applicationservice.dto;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class ApplicationRequestDto {
    private Long citizenId;
    private Long programId;
}
