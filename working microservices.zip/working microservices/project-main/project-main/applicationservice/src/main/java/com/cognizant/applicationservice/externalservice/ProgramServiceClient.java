package com.cognizant.applicationservice.externalservice;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "program-service")
public interface ProgramServiceClient {

    @GetMapping("/programs/{id}")
    Object getProgramById(@PathVariable Long id);
}
