package com.cognizant.applicationservice.service;

import com.cognizant.applicationservice.dao.EligibilityCheckRepository;
import com.cognizant.applicationservice.dto.*;
import com.cognizant.applicationservice.entity.EligibilityCheck;
import com.cognizant.applicationservice.exception.ResourceNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EligibilityCheckServiceImpl implements EligibilityCheckService {

    private final EligibilityCheckRepository checkRepository;

    @Override
    public EligibilityCheckResponseDto createCheck(EligibilityCheckRequestDto dto) {
        EligibilityCheck check = EligibilityCheck.builder()
                .applicationId(dto.getApplicationId()).officerId(dto.getOfficerId())
                .result(dto.getResult()).notes(dto.getNotes()).build();
        return toDto(checkRepository.save(check));
    }

    @Override
    public EligibilityCheckResponseDto getCheckById(Long id) {
        return toDto(checkRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Eligibility check not found: " + id)));
    }

    @Override
    public List<EligibilityCheckResponseDto> getChecksByApplication(Long applicationId) {
        return checkRepository.findByApplicationId(applicationId).stream().map(this::toDto).collect(Collectors.toList());
    }

    private EligibilityCheckResponseDto toDto(EligibilityCheck c) {
        return EligibilityCheckResponseDto.builder()
                .checkId(c.getCheckId()).applicationId(c.getApplicationId())
                .officerId(c.getOfficerId()).result(c.getResult())
                .date(c.getDate()).notes(c.getNotes()).build();
    }
}
