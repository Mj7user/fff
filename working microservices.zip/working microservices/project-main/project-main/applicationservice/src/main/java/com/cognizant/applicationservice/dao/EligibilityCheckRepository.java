package com.cognizant.applicationservice.dao;

import com.cognizant.applicationservice.entity.EligibilityCheck;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EligibilityCheckRepository extends JpaRepository<EligibilityCheck, Long> {
    List<EligibilityCheck> findByApplicationId(Long applicationId);
}
