package com.cognizant.disbursementservice.controller;

import com.cognizant.disbursementservice.dto.DisbursementRequestDto;
import com.cognizant.disbursementservice.dto.DisbursementResponseDto;
import com.cognizant.disbursementservice.service.DisbursementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/disbursements")
@RequiredArgsConstructor
public class DisbursementController {

    private final DisbursementService disbursementService;

    @PostMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<DisbursementResponseDto> createDisbursement(
            @Valid @RequestBody DisbursementRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(disbursementService.createDisbursement(dto));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','SERVICE')")
    public ResponseEntity<DisbursementResponseDto> getDisbursementById(@PathVariable Long id) {
        return ResponseEntity.ok(disbursementService.getDisbursementById(id));
    }

    @GetMapping("/application/{applicationId}")
    @PreAuthorize("hasAnyRole('CITIZEN','WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<DisbursementResponseDto>> getDisbursementsByApplication(
            @PathVariable Long applicationId) {
        return ResponseEntity.ok(disbursementService.getDisbursementsByApplication(applicationId));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','SERVICE')")
    public ResponseEntity<List<DisbursementResponseDto>> getAllDisbursements() {
        return ResponseEntity.ok(disbursementService.getAllDisbursements());
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR')")
    public ResponseEntity<DisbursementResponseDto> updateStatus(
            @PathVariable Long id,
            @RequestParam String status) {
        return ResponseEntity.ok(disbursementService.updateStatus(id, status));
    }
}
