package com.cognizant.disbursementservice;
import org.springframework.boot.SpringApplication; import org.springframework.boot.autoconfigure.SpringBootApplication; import org.springframework.cloud.openfeign.EnableFeignClients;
@SpringBootApplication @EnableFeignClients
public class DisbursementserviceApplication { public static void main(String[] args) { SpringApplication.run(DisbursementserviceApplication.class, args); } }
