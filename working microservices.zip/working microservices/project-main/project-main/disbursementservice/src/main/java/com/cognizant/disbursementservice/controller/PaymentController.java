package com.cognizant.disbursementservice.controller;
import com.cognizant.disbursementservice.dto.*; import com.cognizant.disbursementservice.service.PaymentService;
import lombok.RequiredArgsConstructor; import org.springframework.http.*; import org.springframework.security.access.prepost.PreAuthorize; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/payments") @RequiredArgsConstructor
public class PaymentController {
    private final PaymentService paymentService;
    @PostMapping
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','ADMINISTRATOR')")
    public ResponseEntity<PaymentResponseDto> create(@RequestBody PaymentRequestDto dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(paymentService.createPayment(dto));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR','SERVICE')")
    public ResponseEntity<PaymentResponseDto> getById(@PathVariable Long id) {
        return ResponseEntity.ok(paymentService.getPaymentById(id));
    }

    @GetMapping("/disbursement/{disbursementId}")
    @PreAuthorize("hasAnyRole('WELFARE_OFFICER','PROGRAM_MANAGER','ADMINISTRATOR','SERVICE')")
    public ResponseEntity<List<PaymentResponseDto>> getByDisbursement(@PathVariable Long disbursementId) {
        return ResponseEntity.ok(paymentService.getPaymentsByDisbursement(disbursementId));
    }
}


