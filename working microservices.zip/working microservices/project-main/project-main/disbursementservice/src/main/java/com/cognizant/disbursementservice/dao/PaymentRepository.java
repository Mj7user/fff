package com.cognizant.disbursementservice.dao;
import com.cognizant.disbursementservice.entity.Payment; import org.springframework.data.jpa.repository.JpaRepository; import java.util.List;
public interface PaymentRepository extends JpaRepository<Payment, Long> { List<Payment> findByDisbursementId(Long disbursementId); }
