import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { UserService } from '../../../core/services/user.service';
import { CitizenService } from '../../../core/services/citizen.service';
import { Role } from '../../../core/models/role.enum';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private authService = inject(AuthService);
  private userService = inject(UserService);
  private citizenService = inject(CitizenService);
  private router = inject(Router);

  loginForm: FormGroup = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  loading = false;
  errorMsg = '';

  isInvalid(field: string): boolean {
    const ctrl = this.loginForm.get(field);
    return !!(ctrl && ctrl.invalid && ctrl.touched);
  }

  onSubmit(): void {
    if (this.loginForm.invalid) { this.loginForm.markAllAsTouched(); return; }
    this.loading = true;
    this.errorMsg = '';

    this.authService.login(this.loginForm.value).subscribe({
      next: (response) => {
        // After login, resolve the userId from the backend.
        // Strategy depends on the user's role:
        //
        // Officers/Admins: GET /users/getallusers → find by email → extract userId
        // Citizens: GET /users/getallusers is 403, so we try it and if it fails,
        //           the dashboard will still attempt /citizens/user/{userId} once
        //           userId becomes available. As a fallback, we search all users
        //           but gracefully handle failure.
        //
        // NOTE: The backend's GET /users/email/{email} returns UserDto which has
        // NO userId field (only email, role, password). This is a backend limitation.
        // The ideal fix is adding userId to LoginResponseDto on the backend side.

        this.resolveUserId(response.email, response.role);
      },
      error: (err) => {
        this.errorMsg = err.error?.message || err.error || 'Invalid credentials. Please try again.';
        this.loading = false;
      }
    });
  }

  private resolveUserId(email: string, role: string): void {
    this.userService.getAllUsers().subscribe({
      next: (users) => {
        const match = users.find(u => u.email === email);
        if (match) {
          this.authService.setUserId(match.userId);

          // If CITIZEN, redirect to profile edit page
          const cleanRole = role.replace('ROLE_', '');
          if (cleanRole === Role.CITIZEN) {
            this.citizenService.getCitizenByUserId(match.userId).subscribe({
              next: (citizen) => {
                this.authService.setCitizenId(citizen.citizenId);
                this.router.navigate(['/citizens/edit', citizen.citizenId]);
                this.loading = false;
              },
              error: () => {
                // If citizen profile doesn't exist yet, go to dashboard
                this.router.navigate(['/dashboard']);
                this.loading = false;
              }
            });
            return;
          }
        }
        this.router.navigate(['/dashboard']);
        this.loading = false;
      },
      error: () => {
        this.router.navigate(['/dashboard']);
        this.loading = false;
      }
    });
  }
}
