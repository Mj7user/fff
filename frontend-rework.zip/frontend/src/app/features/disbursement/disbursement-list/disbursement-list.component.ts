import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DisbursementService } from '../../../core/services/disbursement.service';
import { AuthService } from '../../../core/services/auth.service';
import { DisbursementResponse } from '../../../core/models/application.model';
import { Role } from '../../../core/models/role.enum';
import { LoaderComponent } from '../../../shared/components/loader/loader.component';

@Component({
  selector: 'app-disbursement-list',
  standalone: true,
  imports: [CommonModule, LoaderComponent, FormsModule],
  templateUrl: './disbursement-list.component.html',
  styleUrl: './disbursement-list.component.css'
})
export class DisbursementListComponent implements OnInit {
  private disbursementService = inject(DisbursementService);
  private authService = inject(AuthService);

  disbursements: DisbursementResponse[] = [];
  statusUpdates: Record<number, string> = {};
  loading = true;
  newDisb = { applicationId: 0, citizenId: 0, amount: 0 };

  get canCreate(): boolean {
    return this.authService.hasRole(Role.WELFARE_OFFICER, Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }
  get canUpdate(): boolean {
    return this.authService.hasRole(Role.WELFARE_OFFICER, Role.PROGRAM_MANAGER, Role.ADMINISTRATOR);
  }

  ngOnInit(): void { this.loadDisbursements(); }

  loadDisbursements(): void {
    this.disbursementService.getAllDisbursements().subscribe({
      next: data => {
        this.disbursements = data;
        data.forEach(d => this.statusUpdates[d.disbursementId] = d.status);
        this.loading = false;
      },
      error: () => this.loading = false
    });
  }

  createDisbursement(): void {
    this.disbursementService.createDisbursement(this.newDisb).subscribe({
      next: () => { this.newDisb = { applicationId: 0, citizenId: 0, amount: 0 }; this.loadDisbursements(); },
      error: err => alert(err.error || 'Failed to create disbursement')
    });
  }

  updateStatus(id: number): void {
    this.disbursementService.updateDisbursementStatus(id, this.statusUpdates[id]).subscribe({
      next: updated => {
        const idx = this.disbursements.findIndex(d => d.disbursementId === id);
        if (idx >= 0) this.disbursements[idx] = updated;
      },
      error: err => alert(err.error || 'Update failed')
    });
  }

  viewPayments(disbursementId: number): void {
    this.disbursementService.getPaymentsByDisbursement(disbursementId).subscribe({
      next: payments => alert(
        payments.length === 0
          ? 'No payments for this disbursement.'
          : payments.map(p => `Payment #${p.paymentId}: ${p.method} — ${p.status}`).join('\n')
      ),
      error: () => alert('Failed to load payments')
    });
  }

  getStatusClass(status: string): string {
    const map: Record<string, string> = {
      PROCESSED: 'badge-success', PENDING: 'badge-warning',
      FAILED: 'badge-danger', CANCELLED: 'badge-danger'
    };
    return map[status] || 'badge-neutral';
  }
}
