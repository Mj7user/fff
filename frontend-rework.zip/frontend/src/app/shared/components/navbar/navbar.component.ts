import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { NotificationService } from '../../../core/services/notification.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit {
  authService = inject(AuthService);
  private notificationService = inject(NotificationService);
  private router = inject(Router);
  unreadCount = 0;

  get userInitial(): string {
    const email = this.authService.getCurrentUser()?.email;
    return email ? email.charAt(0).toUpperCase() : '?';
  }

  ngOnInit(): void {
    if (this.authService.isAuthenticated()) {
      this.loadUnreadCount();
    }
  }

  loadUnreadCount(): void {
    const userId = this.authService.getUserId();
    if (userId) {
      this.notificationService.getUnreadNotifications(userId).subscribe({
        next: (notifs) => this.unreadCount = notifs.length,
        error: () => this.unreadCount = 0
      });
    }
  }

  goToNotifications(): void {
    this.router.navigate(['/notifications']);
  }

  logout(): void {
    this.authService.logout();
  }
}
