export const environment = {
  production: true,
  apiUrl: 'https://api.welfare-portal.com'
};
